/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen1;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;



/**
 *
 * @author nicole
 */
public class TareaPantalla extends Application {

private TextArea txtdescripcion = new TextArea();
    private RadioButton rdSi = new RadioButton("Si");
    private RadioButton rdNo = new RadioButton("No");
    private ToggleGroup tggDatos = new ToggleGroup();
    private ListView lstRol = new ListView(addList());
    private Button btnAgregar = new Button("Agregar");
    private TableView<TareaPantalla> tbTarea = new TableView<>();
    private DatePicker dateFecha = new  DatePicker();


    
    
    @Override
    public void start(Stage primaryStage) {
        formatoComponentes(); 
        tbTarea.getColumns().addAll(this.getColummnDescrip(), this.getColummnDatos(), this.getColummnRol(), this.getColummnFecha());
        VBox root = new VBox();
        root.getChildren().add(nuevaVenta());
        root.getChildren().add(this.tbTarea);

        

        Scene scene = new Scene(root, 400, 250);
        
        primaryStage.setTitle("Ingreso de tareas");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private GridPane nuevaVenta() {
        
        GridPane grid = new GridPane();
        GridPane panel2 = new GridPane();
      
        grid.addRow(0, new Label("Ingreso de tareas"));
        grid.addRow(1, new Label("Descripcion"), this.txtdescripcion);
        grid.addRow(3, new Label("Datos adjuntos"), panel2);
        grid.addRow(4, new Label("Rol"), this.lstRol);
        grid.addRow(5, new Label("Fecha de finalizacion"), this.dateFecha);
        
        panel2.addRow(0, this.rdNo, this.rdSi);
  
        grid.addRow(7,btnAgregar);


        
        btnAgregar.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                guardar();
            }
        });

        
        return grid;
    }
    
    public void formatoComponentes(){
        tggDatos.getToggles().addAll(rdSi,rdNo);

    }

    public ObservableList<String> addList() {
        ObservableList<String> data = FXCollections.observableArrayList("Cambiar","Cambiar","Cambiar","Cambiar");
        return data;        
    }
    
    public TableColumn<TareaPantalla,String> getColummnDescrip(){
       TableColumn<TareaPantalla, String> colNombre = new TableColumn<>("descripcion");
       colNombre.setCellValueFactory( new PropertyValueFactory<>("descripcion"));


       return colNombre;
   }
    public TableColumn<TareaPantalla,String> getColummnDatos(){
       TableColumn<TareaPantalla, String> col = new TableColumn<>("datos hh");
       col.setCellValueFactory( new PropertyValueFactory<>("datos"));


       return col;
   }
    public TableColumn<TareaPantalla,String> getColummnRol(){
       TableColumn<TareaPantalla, String> col = new TableColumn<>("rol");
       col.setCellValueFactory( new PropertyValueFactory<>("rol"));


       return col;
   }
    
    public TableColumn<TareaPantalla,String> getColummnFecha(){
       TableColumn<TareaPantalla, String> col = new TableColumn<>("fechaFinalizacion");
       col.setCellValueFactory( new PropertyValueFactory<>("fechaFinalizacion"));

       return col;
   }
    
    public boolean validacion(){
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        boolean correcto = false;
        alerta.setTitle("Error");
 
        if (this.txtdescripcion.getText().isEmpty()) {
            alerta.setContentText("Ingrese descripcion");
       alerta.show();            
            return correcto;
        }
        if(this.dateFecha.getValue()== null){
            alerta.setContentText("Ingrese fecha de finalizacion");
            alerta.show();
            return correcto;
        }
        if (!(this.rdNo.isSelected() || this.rdSi.isSelected())) {
            alerta.setContentText("Ingrese datos adjuntos");
                alerta.show();
                return correcto;
        }
        if(this.lstRol.getSelectionModel().getSelectedIndex() == -1){
            alerta.setContentText("Ingrese rol");
            alerta.show();
            return correcto;
        }

        return true;
    }
    
    public void guardar(){
        if(validacion()){
        String actividad ="";
        if(this.rdSi.isSelected()){
           actividad = this.rdSi.getText();
        }
        if(this.rdNo.isSelected()){
            actividad = this.rdNo.getText();
        }
        
        Tareas objPersona = new Tareas(this.txtdescripcion.getText(), actividad,
                                              this.lstRol.getSelectionModel().getSelectedItem().toString(),
                                              this.dateFecha.getValue().toString());
        
        this.tbTareaPantalla.getItems().add(objPersona);
        }
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
