/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzaorder;

import static java.awt.SystemColor.text;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author nicole robles
 */
public class PizzaOrder extends Application {
    private GridPane grid;
   
    @Override
    public void start(Stage primaryStage) {  
   
        grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        
        ToggleGroup groupGender = new ToggleGroup();

        RadioButton SmallRadio = new RadioButton("Small"); 
        SmallRadio.setToggleGroup(groupGender); 
        RadioButton MediumRadio = new RadioButton("Medium"); 
        MediumRadio.setToggleGroup(groupGender); 
        RadioButton LargeRadio = new RadioButton("Large"); 
        LargeRadio.setToggleGroup(groupGender); 
      
      
        RadioButton ThinRadio = new RadioButton("Thin"); 
        ThinRadio.setToggleGroup(groupGender); 
        RadioButton ThickRadio = new RadioButton("Thick"); 
        ThickRadio.setToggleGroup(groupGender); 
      
        
        CheckBox PepperoniCheckBox = new CheckBox("Pepperoni"); 
        PepperoniCheckBox.setIndeterminate(false); 
        CheckBox SausageCheckBox = new CheckBox("Sausage"); 
        SausageCheckBox.setIndeterminate(false); 
        CheckBox LinguicaCheckBox = new CheckBox("Linguica"); 
        LinguicaCheckBox.setIndeterminate(false); 
        CheckBox OlivesCheckBox = new CheckBox("Olives"); 
        OlivesCheckBox.setIndeterminate(false);
        CheckBox MushroomsCheckBox = new CheckBox("Mushrooms"); 
        MushroomsCheckBox.setIndeterminate(false);
        CheckBox TomatoesCheckBox = new CheckBox("Tomatoes"); 
        TomatoesCheckBox.setIndeterminate(false);
        CheckBox AnchoviesCheckBox = new CheckBox("Anchovies"); 
        AnchoviesCheckBox.setIndeterminate(false);
        
        
        Button buttonOk = new Button("Ok"); 
        Button buttonCancel = new Button("Cancel"); 
      
        grid.add(new Label ("Order Your Pizza Now!"), 3, 2);
        grid.add(new Label ("Name:"), 2, 8);
        grid.add(new Label ("Phone Number :"), 2, 10);
        grid.add(new Label ("Address:"), 2, 12);
        grid.add(new TextField ("Enter your name here"), 3, 8);
        grid.add(new TextField ("Enter your phone number here"), 3, 10);
        grid.add(new TextField ("Enter your address here"), 3, 12);
        
        grid.add(new Label ("Size"), 2, 14);
        grid.add(SmallRadio, 2, 16);       
        grid.add(MediumRadio, 2, 18);
        grid.add(LargeRadio, 2, 20);
        
        grid.add(new Label ("Crust"), 3, 14);
        grid.add(ThinRadio, 3, 16);       
        grid.add(ThickRadio, 3, 18); 
        
        grid.add(new Label ("Toppings"), 4, 14);
        grid.add(PepperoniCheckBox, 4, 16); 
        grid.add(SausageCheckBox, 5, 18); 
        grid.add(LinguicaCheckBox, 5, 14); 
        grid.add(OlivesCheckBox, 5, 16); 
        grid.add(MushroomsCheckBox, 6, 18); 
        grid.add(TomatoesCheckBox, 6, 14); 
        grid.add(AnchoviesCheckBox, 6,16 ); 
        
        
        grid.add(buttonOk, 4, 22); 
        grid.add(buttonCancel, 5, 22); 
        
        
    
        TextField TxfMatricula = new TextField();
         
        TxfMatricula.setPromptText("Ingrese el numero de la matricula del vehiculo");
        
        grid.setMinSize(500, 600); 
        Scene s = new Scene(grid);
        primaryStage.setTitle("Pizza Order!");
        primaryStage.setScene(s);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
